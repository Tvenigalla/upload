export default class ENV{
    public static BASE_UI_URL = process.env.BASE_UI_URL
    public static EMAIL_ID = process.env.EMAIL_ID
    public static PASSWORD = process.env.PASSWORD
}